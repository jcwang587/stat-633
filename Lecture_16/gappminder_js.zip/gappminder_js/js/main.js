    // Helper for getting unique values
    function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
    }

    function min_na_rm(arr) {
    var min = arr[0];
    for (let i = 1; i < arr.length; ++i) {
        if (arr[i] < min) {
        min = arr[i];
        }
    }

    return min     
    }

    function max_na_rm(arr) {
    var max = arr[0];
    for (let i = 1; i < arr.length; ++i) {
        if (arr[i] > max) {
        max = arr[i];
        }
    }

    return max     
    }

    var all_years = gapminder.map(function(value) { return value.year; })
    all_years = all_years.filter(onlyUnique)
    all_years = all_years.sort()

    var slider = document.getElementById("yearSlider");
    slider.min = min_na_rm(all_years)
    slider.value = slider.min
    slider.max = max_na_rm(all_years)
    slider.step = all_years[1] - all_years[0]
    var output = document.getElementById("showYear");
    output.innerHTML = slider.value;

    slider.oninput = function() {
        output.innerHTML = this.value;
        drawPlot(this.value)
    }

  function drawPlot(yr) {
      var gapminder_current_year = gapminder.filter(row => row.year == yr);

      var all_continents = gapminder_current_year.map(function(value) { return value.continent; })
      var continents = all_continents.filter(onlyUnique)


      var data = []
      for (var c in continents) {

      var gapminder_filter_continent = gapminder_current_year.filter(row => row.continent == continents[c]);

      var trace = {
          x: gapminder_filter_continent.map(function(value) { return value.gdpPercap; }),
          y: gapminder_filter_continent.map(function(value) { return value.lifeExp; }),
          mode: 'markers',
          name: continents[c],
          marker: {
              size: gapminder_filter_continent.map(function(value) { return 2 * value.size; }),
              color: gapminder_filter_continent.map(function(value) { return value.color; })
          },
          // https://plotly.com/javascript/hover-text-and-formatting/
          // hovertemplate: "%{text}",
          hoverinfo: 'text',
          text: 
          gapminder_filter_continent.map(function(value) {
              var t = value.country  
              t += " (" + value.continent + ")"
              t += "<br>Population: " + value.pop.toLocaleString('en-US')
              t += "<br>GDP per capita: " + value.gdpPercap.toLocaleString('en-US')
              t += "<br>Life expectancy: " + value.lifeExp.toLocaleString('en-US')
              return t
              })
      };

      data.push(trace)

      }


      var allGdppercap = gapminder.map(function(value) { return value.gdpPercap; })
      var allLifeExp = gapminder.map(function(value) { return value.lifeExp; })

      var layout = {
      xaxis: {
          autorange: false,
          title: "GDP per capita (US$, inflation-adjusted, log scale)",
          type: 'log',
          // range: [Math.min(allGdppercap), Math.max(allGdppercap)] doesn't work because of 'udefined'
          range: [Math.log10(min_na_rm(allGdppercap)), Math.log10(max_na_rm(allGdppercap)) + 0.01]
      },
      yaxis: {
          autorange: false,
          title: "Life expectancy at birth, in years",
          range: [min_na_rm(allLifeExp) - 5, max_na_rm(allLifeExp) + 5]
      },
      plot_bgcolor: "rgb(0.92, 0.92, 0.92)",
      paper_bgcolor: "rgb(0.85, 0.85, 0.85)",
      }

      Plotly.newPlot('gapminder_plotly', data, layout);
  }

  drawPlot(slider.value)
