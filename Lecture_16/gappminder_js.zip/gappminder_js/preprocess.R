library(tidyverse)

gapminder <- gapminder::gapminder

library(jsonlite)
gapminder_json <- toJSON(gapminder)
fileConn <- file("js/data.js")
writeLines(paste0("var gapminder = ", gapminder_json), fileConn)
close(fileConn)

# write_csv(gapminder, "gapminder.csv")

color_code <- 
  tibble(
    continent = unique(gapminder$continent),
    color = RColorBrewer::brewer.pal(length(unique(gapminder$continent)), "Dark2")
  )

gapminder_color <-
  gapminder %>%
  left_join(color_code, by = "continent")

gapminder_color_json <- toJSON(gapminder_color)
fileConn <- file("js/data_color.js")
writeLines(paste0("var gapminder = ", gapminder_color_json), fileConn)
close(fileConn)

# write_csv(gapminder_color, "gapminder_color.csv")

gapminder_color_size <-
  gapminder_color %>%
  mutate(size = 5 + 40 * (pop - min(pop)) / max(pop))

gapminder_color_size_json <- toJSON(gapminder_color_size)
fileConn <- file("js/data_color_size.js")
writeLines(paste0("var gapminder = ", gapminder_color_size_json), fileConn)
close(fileConn)

# write_csv(gapminder_color_size, "gapminder_color_size.csv")
